# ⏱ Uptime Bot Altyapısı

- **config.json** dosyasından **token** bilgilerini ayarla.
- **events -> ready.js** dosyasından botun durumunu değiştirebilirsin.

# 🔎 İletişim

- Her türlü iletişim için Discord : [Void](https://discord.gg/dcbot) veya [Larex](https://discord.com/users/752910734748549161) [Sentinel](https://discord.com/users/690954493675700485)


- ![](https://img.shields.io/github/stars/larexq/uptime) ![](https://img.shields.io/github/forks/larexq/uptime) ![](https://img.shields.io/github/v/tag/larexq/uptime) ![](https://img.shields.io/github/issues/larexq/uptime)